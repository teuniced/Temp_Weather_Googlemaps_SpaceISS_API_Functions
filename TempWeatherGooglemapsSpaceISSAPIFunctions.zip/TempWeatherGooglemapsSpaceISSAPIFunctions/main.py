import urllib.request 
import json 
import time
import statistics as stats



print(" QUESTION 1 ".center(60,"~"))
url = 'http://api.open-notify.org/astros.json' 
response = urllib.request.urlopen(url)
result = json.loads(response.read())
def space_list():
    """ Functions and API: People in space right now """
    print("Here are the names of people in space right now:")
    for names in result["people"]: #loop to print each response in dictionary 'result'
        print("\t",names["name"])

space_list()


print(" QUESTION 2 ".center(60,"~"))
key = 'dea9391be0d971eb85c46019ea407f29'
city = 'abuja'
def weather_abuja():
    """ Functions: current weather in the city I was born """
    url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={key}'
    response = urllib.request.urlopen(url)
    result = json.loads(response.read())
    print(result)
    print (f"Today, the weather in {(city).title()} is {round(result['main']['temp']-273.15,2)}°C \n")                            
    #prints value in key 'temp' inside 'main' and converts Kelvin into Celsius 
weather_abuja()

print(" QUESTION 3 ".center(60,"~"))
def iss_countryweather():
    """Function returns location of the ISS with additional if statements"""
    #Here's the ISS Location API
    url = 'http://api.open-notify.org/iss-now.json'
    response = urllib.request.urlopen(url)
    result = json.loads(response.read())
    lat = result["iss_position"]["latitude"]
    lon = result["iss_position"]["longitude"]
    print('Link to Google Maps ↓↓')
    print(f'https://www.google.com/maps/place/{lat}+{lon}')

     #passing neccessary info from ISS API to Weather API i.e longitude and latitude 
    api_key = 'dea9391be0d971eb85c46019ea407f29'
    url2 = f'https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}'
    response2 = urllib.request.urlopen(url2)
    result2 = json.loads(response2.read())
    countrycode = '' #variable that houses country code if present in the Weather API
   
    #using restcountries api to get country name from country code    
    if 'country' in result2['sys'] :
        countrycode = result2['sys']['country'] 
        url3 = f'https://restcountries.com/v3.1/alpha/{countrycode}'
        response3 = urllib.request.urlopen(url3)
        result3 = json.loads(response3.read())
        print(result3,'\n') #valid when there's a country present in dictionary 'result2'
        
    #conditions for return and print statement depending on if country code is presnt 
    if countrycode == '':
        countryname = 'water' 
        weather = (result2['main']['temp'])-273.15
        return countryname,weather
    else:
        #if country code is present, country name is obtained from a dictionary in the list 'result3' using the 'rest countries' API
        countryname = result3[0]['name']['common']
        weather = (result2['main']['temp'])-273.15
        return countryname,weather
        
countryname,weather = iss_countryweather()
print(f'ISS is over {countryname} and the weather is {round(weather,2)}°C\n')





print(" Download,store the temperature for a city".center(75,"~"))
for value in range(200):
    #using the weather api to download and read the data into variable 'result' and 
    #append the read values into "weather.txt" file
    key = 'dea9391be0d971eb85c46019ea407f29'
    city = 'Abuja'
    url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={key}'
    response = urllib.request.urlopen(url)
    result = json.loads(response.read())
    file = open("weather.txt","a")
    file.write(f"{round(float(result['main']['temp']-273.15),2)}\n")
    file.close()
    #print(f"{round(result['main']['temp']-273.15,2)}°C")


print(" Read and write previous result in into a list".center(75,"~"))
'Use the statistics package to print the min, max, median.'
citytemp = [] #list to hold incoming result from previous result in que 5
with open("weather.txt") as file: 
    """opens the file weathertxt in read mode and sends values in it to file and 
    appends the values to list citytemp"""
    for values in file:
        citytemp.append((float(values.strip())))
                        
print(citytemp)
print(f"The min temp for the city of {city} today is: {min(citytemp)}°C\nThe max temp for the city of {city} today is:\
 {max(citytemp)}°C\nThe median temp for the city of {city} today is: {stats.median(citytemp)}°C")
#print(type(citytemp))